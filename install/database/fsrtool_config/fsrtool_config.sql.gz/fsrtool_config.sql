INSERT IGNORE INTO fsrtool_config (id, name, value) VALUES (1, 'Version', 1.0);
