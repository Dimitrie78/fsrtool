<?php

class User
{
	public $charID;
	public $keyID;
	public $vCODE;
	
	public function __construct() {
		
	}
}

?>