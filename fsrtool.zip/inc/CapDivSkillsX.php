<?php

$CapSkillsX = array();


//Amarr
$CapSkillsX['Amarr'][24311] = 'Carrier';
$CapSkillsX['Amarr'][20525] = 'Dread';
$CapSkillsX['Amarr'][3347]  = 'Titan';

//Caldari
$CapSkillsX['Caldari'][24312] = 'Carrier';
$CapSkillsX['Caldari'][20530] = 'Dread';
$CapSkillsX['Caldari'][3346]  = 'Titan';

//Gallente
$CapSkillsX['Gallente'][24313] = 'Carrier';
$CapSkillsX['Gallente'][20531] = 'Dread';
$CapSkillsX['Gallente'][3344]  = 'Titan';

//Minmatar
$CapSkillsX['Minmatar'][24314] = 'Carrier';
$CapSkillsX['Minmatar'][20532] = 'Dread';
$CapSkillsX['Minmatar'][3345]  = 'Titan';


// Carrier
$CapSkillsX['Carrier'][20342] = 'Advanced Spaceship Command';
$CapSkillsX['Carrier'][20533] = 'Capital Ships';
$CapSkillsX['Carrier'][21611] = 'Jump Drive Calibration';
$CapSkillsX['Carrier'][21610] = 'Jump Fuel Conservation';
$CapSkillsX['Carrier'][21803] = 'Capital Repair Systems';
$CapSkillsX['Carrier'][21802] = 'Capital Shield Operation';
$CapSkillsX['Carrier'][24568] = 'Capital Remote Armor Repair Systems';
$CapSkillsX['Carrier'][24571] = 'Capital Shield Emission Systems';
$CapSkillsX['Carrier'][24572] = 'Capital Energy Emission Systems';
$CapSkillsX['Carrier'][27936] = 'Capital Remote Hull Repair Systems';
$CapSkillsX['Carrier'][27906] = 'Tactical Logistics Reconfiguration';
$CapSkillsX['Carrier'][23069] = 'Fighters';
$CapSkillsX['Carrier'][32339] = 'Fighter Bombers';

// Dread
$CapSkillsX['Dread'][20342] = 'Advanced Spaceship Command';
$CapSkillsX['Dread'][20533] = 'Capital Ships';
$CapSkillsX['Dread'][21611] = 'Jump Drive Calibration';
$CapSkillsX['Dread'][21610] = 'Jump Fuel Conservation';
$CapSkillsX['Dread'][21803] = 'Capital Repair Systems';
$CapSkillsX['Dread'][21802] = 'Capital Shield Operation';
$CapSkillsX['Dread'][22043] = 'Tactical Weapon Reconfiguration';

$CapSkillsX['Dread'][20327] = 'Capital Energy Turret';
$CapSkillsX['Dread'][21668] = 'Citadel Torpedoes';
$CapSkillsX['Dread'][32435] = 'Citadel Cruise Missiles';
$CapSkillsX['Dread'][21666] = 'Capital Hybrid Turret';
$CapSkillsX['Dread'][21667] = 'Capital Projectile Turret';

?>
