$.fn.qtip.styles.fsr = {
   background: '#626456',
   color: 'white',
   border: {
      width: 3,
      radius: 2,
      color: '#333'
   },
   position: {
      corner: {
        target: 'topRight',
        tooltip: 'bottomLeft'
      }
   },
   name: 'dark'
}
