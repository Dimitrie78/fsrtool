<?php
set_time_limit(0);
/* $host		= "db384066247.db.1and1.com";
$user		= "dbo384066247";
$password	= "egon2212";
$database	= "db384066247";
$dbprefix   = "fsrtool_"; */

$host		= "localhost";
$user		= "fsrtool";
$password	= "fsrtool";
$database	= "fsrtool";
$dbprefix   = "fsrtool_";

$dbdir = 'install/database/';

$db = new mysqli( $host, $user, $password, $database );

/* $res = $db->query("SHOW VARIABLES LIKE 'max%'");
while( $row = $res->fetch_array() ) {
	echo $row[0].' - '.$row[1].'<br>';
} */

echo checkdir($dbdir);

$res = $db->query("SHOW TABLES");
while( $row = $res->fetch_array() ) {
	$tables[] = $row[0];
	
	echo checkdir($dbdir.$row[0]);
	$res2 = $db->query("SHOW CREATE TABLE $row[0]");
	
	$res3 = $db->query("SELECT count(*) AS cnt FROM $row[0]");
	$row3 = $res3->fetch_array();
	$res3->close();
	
	#if ($row[0] != 'fsrtool_cron') continue;
	
	while( $row2 = $res2->fetch_array() ) {
		tablexml($row2[0], $row3['cnt'], $row2[1], $dbdir);
	}
	
	if ($row3['cnt'] == 0) continue;
	
	if ($row[0] == 'fsrtool_eve_mapdenormalize') {
		$res4 = $db->query("SELECT * FROM $row[0] WHERE regionID IS NULL");
		$count = $res4->num_rows;
		$counter = 0;
		$str = "";
		$zp = gzopen($dbdir.$row[0].'/'.$row[0].'.sql.gz', "w9");
		while( $row4 = $res4->fetch_assoc() ) {
			$counter ++;
			foreach ( $row4 as $key => $value ) {
				if (is_numeric( $value )) {
					if (is_float( $value )) {
						$row4[ $key ] = "'".$db->real_escape_string($value)."'";
					} else {
						$row4[ $key ] = $db->real_escape_string($value);
					}
				} elseif (is_null( $value )) {
					$row4[ $key ] = 'NULL';
				} else {
					$row4[ $key ] = "'".$db->real_escape_string($value)."'";
				}
			}
			if ($str == "")	$str = "INSERT IGNORE INTO {$row[0]} (". implode( ", ", array_keys($row4) ) .") VALUES ";
			
			if (strlen($str) >= 995000 || $counter == $count) {
				$str .= "(". implode( ", ", array_values($row4) ) .");\r\n";
				//echo $str;
				gzwrite($zp, $str);
				$str = "";
			} else {
				$str .= "(". implode( ", ", array_values($row4) ) ."),";
			}
		}
		
		
		gzclose($zp);
		$res4->close();
		
		$res5 = $db->query("SELECT regionID FROM fsrtool_eve_mapregions");
		while( $row5 = $res5->fetch_array() ) {
			$res4 = $db->query("SELECT * FROM $row[0] WHERE regionID = $row5[0]");
			$count = $res4->num_rows;
			$counter = 0;
			$str = "";
			$zp = gzopen($dbdir.$row[0].'/'.$row5[0].'.sql.gz', "w9");
			while( $row4 = $res4->fetch_assoc() ) {
				$counter ++;
				foreach ( $row4 as $key => $value ) {
					if (is_numeric( $value )) {
						if (is_float( $value )) {
							$row4[ $key ] = "'".$db->real_escape_string($value)."'";
						} else {
							$row4[ $key ] = $db->real_escape_string($value);
						}
					} elseif (is_null( $value )) {
						$row4[ $key ] = 'NULL';
					} else {
						$row4[ $key ] = "'".$db->real_escape_string($value)."'";
					}
				}
				if ($str == "")	$str = "INSERT IGNORE INTO {$row[0]} (". implode( ", ", array_keys($row4) ) .") VALUES ";
				
				if (strlen($str) >= 995000 || $counter == $count) {
					$str .= "(". implode( ", ", array_values($row4) ) .");\r\n";
					//echo $str;
					gzwrite($zp, $str);
					$str = "";
				} else {
					$str .= "(". implode( ", ", array_values($row4) ) ."),";
				}
			}
			gzclose($zp);
			$res4->close();
		} 
		
	}
	else {
		$res4 = $db->query("SELECT * FROM $row[0]");
		$count = $res4->num_rows;
		$counter = 0;
		$str = "";
		$zp = gzopen($dbdir.$row[0].'/'.$row[0].'.sql.gz', "w9");
		while( $row4 = $res4->fetch_assoc() ) {
			$counter ++;
			foreach ( $row4 as $key => $value ) {
				if (is_numeric( $value )) {
					if (is_float( $value )) {
						$row4[ $key ] = "'".$db->real_escape_string($value)."'";
					} else {
						$row4[ $key ] = $db->real_escape_string($value);
					}
				} elseif (is_null( $value )) {
					$row4[ $key ] = 'NULL';
				} else {
					$row4[ $key ] = "'".$db->real_escape_string($value)."'";
				}
			}
			if ($str == "")	$str = "INSERT IGNORE INTO {$row[0]} (". implode( ", ", array_keys($row4) ) .") VALUES ";
						
			if (strlen($str) >= 995000 || $counter == $count) {
				$str .= "(". implode( ", ", array_values($row4) ) .");\r\n";
				//echo $str;
				gzwrite($zp, $str);
				$str = "";
			} else {
				$str .= "(". implode( ", ", array_values($row4) ) ."),";
			}
		}
		gzclose($zp);
		$res4->close();
	}
	echo $row[0].' - Done<br>';
	
}

contents_xml($tables, '1.0', $dbdir);


function checkdir($dir) {
    $text = '';
    if (!file_exists($dir))
    {
        $text = '<b>Creating '.$dir.' for you...</b><br/>';
        mkdir($dir);
        chmod($dir, 0777);
    }
    if (is_writeable($dir))
    {
        $text .= 'Directory '.$dir.' exists and is writeable. Excellent!<br/>';
    }
    else
    {
        $text .= 'I can\'t write into '.$dir.'. You need to fix that for me before you can continue.<br/>';
        $text .= 'Please issue a "chmod 777 '.$dir.'" on the commandline inside of this directory.<br/>';
        global $stoppage;
        $stoppage = true;
    }
    return $text;
}

function tablexml($name='', $rows='', $structure='', $dir='test/') {
	$xml = new XMLWriter();
	$xml->openMemory();
	$xml->setIndent(true);
	$xml->startDocument('1.0', 'UTF-8');

	$xml->startElement("fsrtool");
		$xml->writeElement("name", $name);
		$xml->writeElement("rows", $rows);
		$xml->writeElement("structure", $structure);
	$xml->endElement();

	$xml->endDocument();

	$x= $xml->outputMemory(true);
	$size = strlen($x);
	
	#header("Content-type: text/xml");
	#echo $x;
	
	$myFile = $dir.$name."/table.xml";
	file_put_contents($myFile, $x);
}

function contents_xml(array $names, $version='1.0', $dir='test/') {
	$xml = new XMLWriter();
	$xml->openMemory();
	$xml->setIndent(true);
	$xml->startDocument('1.0', 'UTF-8');

	$xml->startElement("fsrtool");
	foreach( $names as $name ) {
		$xml->startElement("table");
			$xml->writeElement("name", $name);
			$xml->writeElement("version", $version);
		$xml->endElement();
	}
	$xml->endElement();

	$xml->endDocument();

	$x = $xml->outputMemory(true);
	
	$myFile = $dir."contents.xml";
	file_put_contents($myFile, $x);
}

/* <table>
    <name>fsrtool_alecache</name>
    <version>1.0</version>
</table> */
?>