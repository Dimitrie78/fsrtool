<?php
defined('ACTIVE_MODULE') or die('Restricted access');

require_once('userManager.world.class.php');

?>