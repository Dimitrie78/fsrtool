<?php
defined('ACTIVE_MODULE') or die('Restricted access');

require_once("jb.world.class.php");
require_once("jb.class.php");

?>