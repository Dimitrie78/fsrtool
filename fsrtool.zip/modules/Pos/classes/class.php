<?php
defined('ACTIVE_MODULE') or die('Restricted access');

require_once("Pos.world.class.php");
require_once("Pos.class.php");

?>