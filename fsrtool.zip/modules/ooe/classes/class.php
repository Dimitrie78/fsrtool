<?php
defined('ACTIVE_MODULE') or die('Restricted access');

require_once('ooe.world.class.php');
require_once('functions.php');
require_once('apidb.class.php');
require_once('eveMail.class.php');
require_once('accStatus.class.php');
require_once('eveAssets.class.php');

?>