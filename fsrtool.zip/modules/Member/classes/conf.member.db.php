<?php
########################################################################
# mySQL-Tabellen
define('db_snow_afk_time',	'fsrtool_snow_afk_time');
define('db_snow_alts',		'fsrtool_snow_alts');
define('db_snow_characters','fsrtool_snow_characters');
define('db_snow_evaluation','fsrtool_snow_evaluation');
define('db_snow_jobs',		'fsrtool_snow_jobs');
define('db_snow_kills',		'fsrtool_snow_kills');
define('db_snow_news',		'fsrtool_snow_news');
define('db_snow_tempchars',	'fsrtool_snow_tempchars');
define('db_snow_time',		'fsrtool_snow_time');

?>