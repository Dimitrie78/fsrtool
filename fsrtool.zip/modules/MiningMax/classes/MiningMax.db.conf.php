<?php
defined('fsr_tool') or die;

# Miningbuddy-DB

define('db_host_fsrclan_miningbuddy', 'free-space-ranger.de');
define('db_name_fsrclan_miningbuddy', 'fsrclan_miningbuddy');
define('db_user_fsrclan_miningbuddy', 'adminfsrmbuddy');
define('db_pass_fsrclan_miningbuddy', '8JbJ2mq8');

?>