<?php
defined('fsr_tool') or die;

class MemberDatabase extends Database
{
	function __construct()
	{
		$this->loadSQLStrings();
	}

	function member_get_m()
	{
	
	}
}

?>