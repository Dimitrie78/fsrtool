<?php
########################################################################
# mySQL-Tabellen
define('db_snow_afk_time',	'afk_time');
define('db_snow_alts',		'alts');
define('db_snow_characters','characters');
define('db_snow_evaluation','evaluation');
define('db_snow_jobs',		'jobs');
define('db_snow_kills',		'kills');
define('db_snow_news',		'news');
define('db_snow_tempchars',	'tempchars');
define('db_snow_time',		'time');

# Snowflake DB

define('db_host_fsrclan_member', 'free-space-ranger.de');
define('db_name_fsrclan_member', 'free-space-ranger_members');
define('db_user_fsrclan_member', 'adminfsrmembers');
define('db_pass_fsrclan_member', '5aJEcE3a');

?>